# Deploying to Vercel

This project deploys as **two separate Vercel projects** — one for `backend`,
one for `frontend` — connected by an environment variable. This is the most
reliable way to deploy a split frontend/backend repo on Vercel.

## 1. Deploy the backend

1. Push this repo to GitHub (or use the Vercel CLI, see below).
2. In Vercel: **Add New → Project**, import the repo, and set
   **Root Directory** to `backend`.
3. Framework preset: **Other**. Build command / output directory: leave blank
   (nothing to build, it's a serverless API).
4. Add these Environment Variables (copy from `backend/.env.example`):
   - `MONGO_URI`
   - `JWT_SECRET`
   - `CLIENT_URL` — set this **after** you deploy the frontend (step 2), to
     your frontend's Vercel URL, e.g. `https://your-frontend.vercel.app`
   - `STRIPE_SECRET_KEY`
   - `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` —
     from your Cloudinary dashboard (Settings → Access Keys). Free tier is
     plenty to start.
5. Deploy. Note the resulting URL, e.g. `https://your-backend.vercel.app`.
6. Sanity check: visit `https://your-backend.vercel.app/api/health`.

## 2. Deploy the frontend

1. **Add New → Project**, same repo, **Root Directory** set to `frontend`.
2. Framework preset: **Create React App** (auto-detected).
3. Add this Environment Variable (copy from `frontend/.env.example`):
   - `REACT_APP_API_URL` = your backend URL from step 1, e.g.
     `https://your-backend.vercel.app` (**no trailing slash**)
4. Deploy.
5. Go back to the backend project's settings and set `CLIENT_URL` to this
   frontend URL, then redeploy the backend so CORS allows it.

## Or deploy via CLI (no GitHub needed)

```bash
npm i -g vercel

cd backend
vercel --prod
# follow prompts, then set env vars:
vercel env add MONGO_URI production
vercel env add JWT_SECRET production
vercel env add CLIENT_URL production
vercel env add STRIPE_SECRET_KEY production
vercel --prod   # redeploy with the env vars applied

cd ../frontend
vercel --prod
vercel env add REACT_APP_API_URL production   # paste the backend URL
vercel --prod
```

## ✅ Product images now go through Cloudinary

The seller dashboard compresses photos client-side into base64 and sends
them as JSON to `POST /api/products` / `PUT /api/products/:id`. The backend
now uploads any base64 image it receives straight to Cloudinary and stores
the returned CDN URL on the product — nothing is written to local disk, so
this works correctly on Vercel's read-only filesystem. Deleting a product
also best-effort deletes its Cloudinary images.

You must set the three `CLOUDINARY_*` env vars (step 4 above) or image
uploads will fail. Get them from your Cloudinary dashboard after creating a
free account at cloudinary.com.

**Note on payload size:** Vercel serverless functions hard-cap request
bodies at 4.5MB, so a product with several high-res photos could still hit
that ceiling even after client-side compression. If sellers regularly hit
this, the next step would be uploading images directly from the browser to
Cloudinary (unsigned upload) instead of routing them through the API.

## What changed from your original code

- Added `backend/api/index.js` + rewrote `backend/vercel.json` to Vercel's
  current serverless format (the old `builds`/`routes` config is legacy).
- Made `backend/config/db.js` cache its MongoDB connection across invocations
  and stopped it from calling `process.exit()` on failure (that would crash
  the whole serverless function).
- Replaced hardcoded `http://localhost:5000` in 5 frontend files and in
  `frontend/src/services/api.js` with `process.env.REACT_APP_API_URL`, since
  frontend and backend now live on different domains.
- Added `.env.example` files, `.gitignore` files, and `frontend/vercel.json`
  (SPA rewrite so React Router routes don't 404 on refresh).
- Wired up Cloudinary: added `backend/config/cloudinary.js`, rewrote
  `backend/utils/imageHandler.js` to upload to Cloudinary instead of local
  disk, and updated `productController.js` (create/update/delete) to use it.
- Removed the unused `backend/config/multer.js` and local `backend/uploads`
  folder — multer was never actually wired into any route (product images
  were always sent as base64 JSON, not multipart file uploads), so it was
  dead code.
- Raised the Express JSON body limit from Express's 100kb default to 4mb
  (see payload-size note above) so image-bearing product submissions
  actually reach the server.
